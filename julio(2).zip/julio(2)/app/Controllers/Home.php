<?php

namespace App\Controllers;
use Codeigniter\Controller;
use App\Models\M_kue;


class Home extends BaseController
{
    public function dashboard()
    {
         if (session()->get('level')>0){
        echo view('header');
        echo view('menu');
        echo view('dashboard');
      } else{
        return redirect()->to('home/login');
      }
    }


 public function login()
    {
        echo view('header');
        echo view('login');
    }
   public function aksi_login()
    {
        $u=$this->request->getPost('username');
        $p=$this->request->getPost('password');

        $model = new M_kue();
        $where=array(
            'username'=> $u,
            'password' => $p
        );

        $model = new M_kue();
        $cek = $model->getWhere('user',$where);
        
        if ($cek>0){
         session()->set('id_user',$cek->id_user);
         session()->set('username',$cek->username);
         session()->set('level',$cek->level);
         return redirect()->to('home/dashboard');
     }else{
        return redirect()->to('home/login');
    }
}
public function chat()
    {
        $responseContent = '';

        if ($this->request->getMethod() === 'post') {
            $userInput = $this->request->getPost('user_input');

            // API Key dari OpenAI
            $apiKey = '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'; // Masukkan API Key Anda

            // URL Endpoint dari API OpenAI
            $url = 'https://api.openai.com/v1/chat/completions';
            $data = [
                'model' => 'gpt-3.5-turbo', // Pilih model yang sesuai
                'messages' => [
                    ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                    ['role' => 'user', 'content' => $userInput]
                ],
                'max_tokens' => 150,
                'temperature' => 0.7,
            ];

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ]);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);
            $responseContent = $responseData['choices'][0]['message']['content'] ?? '';
        }

        echo view('header');
        echo view('chat', ['responseContent' => $responseContent]);
    }



}

