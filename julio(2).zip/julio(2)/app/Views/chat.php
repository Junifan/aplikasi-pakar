<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with ChatGPT</title>
</head>
<body>
    <h1>Chat with ChatGPT</h1>
    <form action="<?= base_url('home/chat') ?>" method="post">
        <textarea name="user_input" rows="4" cols="50" placeholder="Type your message..."></textarea><br>
        <input type="submit" value="Send">
    </form>

    <div>
        <h2>Response:</h2>
        <p><?= htmlspecialchars($responseContent) ?></p>
    </div>
</body>
</html>
