<footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © bootstrapdash.com 2020</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Free <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap dashboard templates</a> from Bootstrapdash.com</span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="<?= base_url('vendors/base/vendor.bundle.base.js')?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?= base_url('js/off-canvas.js')?>"></script>
  <script src="<?= base_url('js/hoverable-collapse.js')?>"></script>
  <script src="<?= base_url('js/template.js')?>"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <script src="<?= base_url('vendors/chart.js/Chart.min.js')?>"></script>
  <script src="<?= base_url('vendors/jquery-bar-rating/jquery.barrating.min.js')?>"></script>
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="<?= base_url('js/dashboard.js')?>"></script>
  <!-- End custom js for this page-->
</body>

</html>